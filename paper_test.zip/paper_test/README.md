# ATTP Paper Artifact (`paper_test`)

Slim artifact for the ATTP paper's experiments: the **experiment code** and the
**final result JSONs**. Heavy intermediate stores (per-scenario `.db` files) and
the paper/supplement documents are omitted to keep this bundle small — they live
in the main repository.

## Layout

```
paper_test/
├── python/attp/                 # ATTP package (the method: vertical/horizontal analyzers,
│                                #   prompts, Ed25519 auth, base_models) — import attp.*
├── benchmark/
│   ├── intent_analysis/         # experiment code
│   │   ├── evaluate.py, benchmark_lib.py, generate_all.py, registry.py (+10 registry_*.py)
│   │   ├── calibrate_R_T.py, calibrate_R_S.py, confirm_eval.py, offline_horizontal.py
│   │   └── rq_supplement/       # rq_common.py + rq1..rq4 + ablation + p-sweep scripts
│   └── data/                    # result JSONs only (no .db)
│       ├── results/<model>/     # per-engine: calibrate_R_T/R_S.json, confirm_eval.json, llm_eval_report.json
│       └── rq_results/gemini/   # rq1..rq4 + ablation + exponent result JSONs
├── requirements.txt
└── run.sh / run.bat             # PYTHONPATH wrapper
```

## Result JSON → paper table

| JSON (under `data/`) | Paper table |
|---|---|
| `results/<model>/calibrate_R_T.json` | F1 matrices (vertical, per engine) |
| `results/<model>/calibrate_R_S.json` | R_S selection (per engine) |
| `results/<model>/confirm_eval.json` | horizontal F1 matrix |
| `rq_results/gemini/rq1_results.json` | RQ1 (conflict/omission recall, benign alarm) |
| `rq_results/gemini/rq2_attp_macro.json` | RQ2 / ablation "Full" baseline (Macro-F1) |
| `rq_results/gemini/rq2_direct_judge.json` | RQ2 Direct Judge baseline |
| `rq_results/gemini/rq3_results_test.json` | RQ3 (AUPRC / M-F1 / delay / calls) |
| `rq_results/gemini/rq3_tokens.json` | RQ3 token cost |
| `rq_results/gemini/rq4_results.json`, `rq4_rtt_live.json` | RQ4 (overhead) |
| `rq_results/gemini/rq_ablation_vreasoner.json` | ablation (intent / history) |
| `rq_results/gemini/rq_rs_formulas.json`, `rq_rs_trigger_f1.json` | exponent-p sensitivity + single/dual threshold |

## Re-running

The aggregation scripts read per-scenario `.db` stores, which are **not** in this
bundle. To re-run end-to-end:

1. `pip install -r requirements.txt`
2. Regenerate scenario DBs: `./run.sh benchmark/intent_analysis/generate_all.py`
   (writes `.db` to `benchmark/data/scenarios/`).
3. Run the LLM pipelines (needs `ATTP_RQ_API_KEY`):
   `rq_test_vertical.py` (V-Reasoner on test), `rq3_scorer.py --split test`
   (horizontal confirms), `rq2_direct_judge.py`, `rq_ablation_vreasoner.py`, and
   the per-engine `calibrate_R_T/S` + `confirm_eval`.
4. Re-aggregate (no LLM): `rq3_recompute.py --split test --results-root rq_results`,
   `rq3_tokens.py`, `rq2_attp_macro.py`, `rq4_overhead.py --aggregate`,
   `rq1_evidence.py --recompute`, `rq_rs_formulas.py`, `rq_rs_trigger_f1.py --aggregate`.

`run.sh`/`run.bat` set `PYTHONPATH=python` and run a script from `paper_test/`:
`./run.sh <script.py> [args]` (Windows: `run.bat <script.py> [args]`).

## Notes

- Scenarios are synthetic and deterministic (`registry.py` + 10 `registry_*.py`); no RNG.
- Counts: adapted MisActBench 190 scn / 1436 beh (test), 95 scn / 718 beh (validation); train_B 87 scn / 2387 beh / 174 campaigns; ATTP-Persistent (test) 92 scn / 2232 beh / 197 campaigns (96 mal / 101 benign).
