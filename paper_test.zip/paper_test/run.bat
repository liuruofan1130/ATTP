@echo off
REM Usage: run.bat <script.py> [args...]
cd /d "%~dp0"
set "PYTHONPATH=python;%PYTHONPATH%"
python %*
