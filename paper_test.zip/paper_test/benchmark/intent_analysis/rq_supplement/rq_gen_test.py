"""只生成 test 场景 DB（te001-092），不动 rt/rs。

test = 原 60(attack_type 均衡) + 32 跨会话(horizontal)。清理旧 te*.db 后从 registry 重建。
"""
from __future__ import annotations

import glob
import os
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BENCH = HERE.parent
sys.path.insert(0, str(BENCH))

from benchmark_lib import ScenarioDB
import registry as R

SCEN = BENCH.parent / "data" / "scenarios"
_ILLEGAL = re.compile(r'[<>:"/\\|?*]')


def main():
    # 清理旧 te*.db
    removed = 0
    for f in glob.glob(str(SCEN / "te*.db")):
        try:
            os.unlink(f); removed += 1
        except OSError:
            pass
    print(f"removed {removed} old te*.db")
    te = [s for s in R.ALL_SCENARIOS if s.split == "test"]
    from collections import Counter
    print(f"generating {len(te)} test DBs: {dict(Counter(s.category for s in te))}")
    for spec in te:
        fname = f"{spec.sid}_{_ILLEGAL.sub('_', spec.name)}.db"
        dbp = SCEN / fname
        if dbp.exists():
            os.unlink(str(dbp))
        ScenarioDB(str(dbp), spec).build()
    print(f"done: {len(glob.glob(str(SCEN / 'te*.db')))} te DBs")


if __name__ == "__main__":
    main()
