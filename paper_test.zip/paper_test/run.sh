#!/usr/bin/env bash
# Usage: ./run.sh <script.py> [args...]
# Sets PYTHONPATH so `import attp` resolves, then runs the script from paper_test/.
cd "$(dirname "$0")" || exit 1
export PYTHONPATH="python:${PYTHONPATH}"
python "$@"
